// All jquery scripts
$(document).ready(function ($) {




});